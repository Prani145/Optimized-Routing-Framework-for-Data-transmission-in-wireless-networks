package com.mycompany.utils;

public class Constants {
	public static final String PORT = "port";
	public static final String SYS_IP = "sysIp";
        public static final String SYS_IP1 = "sysIp1";
	public static final String REQ = "req";
	public static final String CHUNK = "chunks";
	public static final String ATTACK = "attack";
	public static final String NORMAL = "normal";
	public static final String ATTACK_IP = "attackSysIp";
	public static final String ATTACK_PORT = "attackPort";
	public static final String SLOT="slot ";
}
